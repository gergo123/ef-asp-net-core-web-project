﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Model.Placeholder
{
    public partial class PlaceholderEntity
    {
        public string LocalString { get; set; }
        public void SomeLogic()
        {

        }
    }
}
