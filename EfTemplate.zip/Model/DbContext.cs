using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using System.Collections.Generic;
using $safeprojectname$.Model.Placeholder;
using $safeprojectname$.Interfaces;
using System.Threading.Tasks;
using System.Threading;
using System;
using System.Linq;
using $safeprojectname$;
using $safeprojectname$.Utils;
using $safeprojectname$.RLS;

namespace $safeprojectname$.Model
{
    public class CoreContext : DbContext
    {
        public DbSet<PlaceholderEntity> Placeholder
        {
            get;
            set;
        }
        public DbSet<PlaceholderEntityACL> PlaceholderACL
        {
            get;
            set;
        }

        public DbSet<RLS.SecurityObject> SecurityObjects
        {
            get;
            set;
        }
        public DbSet<SimplePlaceHolderEntity> SimplePlaceHolders
        {
            get;
            set;
        }

        private readonly CurrentUserProvider UserProvider;

        public CoreContext(CurrentUserProvider userProvider, DbContextOptions<CoreContext> options)
            : base(options)
        {
            UserProvider = userProvider;
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new PlaceholderEntityConfig());
            base.OnModelCreating(modelBuilder);
            //modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            //Configuration.ProxyCreationEnabled = true;
        }

        public override int SaveChanges()
        {
            AddTimestamps();
            return base.SaveChanges();
        }

        public override Task<int> SaveChangesAsync(CancellationToken cancellationToken)
        {
            AddTimestamps();
            return base.SaveChangesAsync(cancellationToken);
        }

        private string currentUsername => SeedUserProvider.User ?? UserProvider.CurrentUserIdentifier;

        private void AddTimestamps()
        {
            var entities = ChangeTracker.Entries().Where(x => x.Entity is IChangeTrackingBase && (x.State == EntityState.Added || x.State == EntityState.Modified));

            foreach (var entity in entities)
            {
                if (entity.State == EntityState.Added)
                {
                    ((IChangeTrackingBase)entity.Entity).DateCreated = DateTime.Now;
                    ((IChangeTrackingBase)entity.Entity).UserCreated = currentUsername;
                }

                if (entity.State == EntityState.Modified)
                {
                    ((IChangeTrackingBase)entity.Entity).DateModified = DateTime.Now;
                    ((IChangeTrackingBase)entity.Entity).UserModified = currentUsername;
                }
            }
        }
    }
}
