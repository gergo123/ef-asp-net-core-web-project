﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Repositories.RLS
{
    public class SecurityGroupRepository : Interfaces.Repositories.Repository<Model.RLS.SecurityGroup>
    {
        public SecurityGroupRepository(DbContext context) : base(context)
        {
        }
    }
}
