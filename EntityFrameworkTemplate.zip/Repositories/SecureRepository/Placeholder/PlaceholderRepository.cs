﻿using $safeprojectname$.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using $safeprojectname$.RLS;
using System.Data.Entity;
using $safeprojectname$.Model.Placeholder;

namespace $safeprojectname$.SecureRepository.PlaceHolder
{
    public class PlaceholderSecureRepository : RLSRepositoryBase<PlaceholderEntity, PlaceholderEntityACL>, IPlaceholderSecureRepository
{
        public IPlaceholderACLRepository ACL;
        public PlaceholderSecureRepository(DbContext context, IUserSecurityObjectsHandler securityObjects, IPlaceholderACLRepository aclRepo) :
            base(context, securityObjects)
        {
            ACL = aclRepo;
        }
    }

    public interface IPlaceholderSecureRepository : IRLSRepository<PlaceholderEntity, PlaceholderEntityACL>
    {
    }
}
