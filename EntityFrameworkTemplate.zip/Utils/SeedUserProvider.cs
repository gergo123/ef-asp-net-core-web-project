﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$.Utils
{
    public static class SeedUserProvider
    {
        public static string User { get; set; }
    }
}
